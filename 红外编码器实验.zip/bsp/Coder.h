#ifndef __CODER_H
#define __CODER_H

#include "stm32f4xx.h"                  // Device header
void Coder_Init(void);


#endif
